// Mobile nav & simple subscribe
const navToggle=document.querySelector('.nav-toggle');const navMenu=document.getElementById('nav-menu');
if(navToggle){navToggle.addEventListener('click',()=>{const isOpen=navMenu.style.display==='flex';navMenu.style.display=isOpen?'none':'flex';navToggle.setAttribute('aria-expanded',String(!isOpen));});}
document.getElementById('year').textContent=new Date().getFullYear();
function subscribe(e){e.preventDefault();const email=document.getElementById('email').value.trim();const msg=document.getElementById('form-msg');if(!email)return false;msg.textContent='Thanks! You\'re on the list.';return false;}
