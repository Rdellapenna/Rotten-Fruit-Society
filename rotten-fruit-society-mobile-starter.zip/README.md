# Rotten Fruit Society — Mobile Upload Starter
Phone-friendly package. Unzip and upload the folder to **Vercel**.

### From your phone
1) Unzip in Files (iOS) or a ZIP app (Android).  
2) Go to **vercel.com** → **New Project → Import → Deploy manually**.  
3) Upload the folder (or ZIP).  
4) In Project → **Settings → Domains**, add `rottenfruitsociety.com`.  
5) Wait a few minutes for SSL (https) to activate.

### Replace assets
Swap images in `/assets` with your artwork. Keep names or update paths in `index.html`.

### Optional
- Hook the email form to Mailchimp, Beehiiv, or ConvertKit.
- Add Analytics (Plausible/GA4) by pasting the script in `<head>`.
